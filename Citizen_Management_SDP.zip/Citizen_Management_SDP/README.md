# Citizen Management — ASP.NET Core MVC Conversion

This is the C#/.NET Core web conversion of the Laravel Citizen Management project.

## Stack
- C# / ASP.NET Core MVC
- .NET 10
- Entity Framework Core 10
- SQLite by default (zero SQL Server setup required)
- Cookie authentication and role authorization
- Stripe.NET integration (optional)
- Razor `.cshtml` views

## Run in Visual Studio
1. Open `Citizen_Management.csproj` or create/open the folder in Visual Studio 2026.
2. Restore NuGet packages.
3. Build the project.
4. Press F5 / Ctrl+F5.

## Run in PowerShell
```powershell
cd D:\Programs\Citizen_Management_NET
dotnet restore
dotnet build
dotnet run
```

Open the HTTPS/HTTP URL printed by `dotnet run`.

## Demo accounts
- Admin: `admin@citizen.local` / `Admin@123`
- Citizen: `citizen@citizen.local` / `Citizen@123`

The first run automatically creates `citizen_management.db` and seed data.

## EF Core migrations
The project uses `EnsureCreated()` for first-run reliability. For a normal migration workflow, install the EF tool and run:

```powershell
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```

After creating the migration, you can replace `EnsureCreated()` with `Database.Migrate()` in `Program.cs`.

## SQL Server
Change the connection string and replace `UseSqlite(...)` with `UseSqlServer(...)` after adding the SQL Server EF Core package.

## Stripe
Set `Stripe:SecretKey` in `appsettings.json` or User Secrets. If it is empty, the application uses the built-in demo payment flow so the project remains runnable without Stripe credentials.

## Important conversion note
The original Laravel application has PHP-specific framework behavior. It cannot be converted by simply renaming `.php` to `.cs`. This project replaces the Laravel runtime with ASP.NET Core MVC patterns while retaining the citizen, property, rental, tax, complaint, verification, revenue, and payment workflows.
