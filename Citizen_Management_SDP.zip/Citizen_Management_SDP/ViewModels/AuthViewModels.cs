namespace Citizen_Management.ViewModels;

public class LoginViewModel
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public bool Remember { get; set; }
}

public class RegisterViewModel
{
    public string FullName { get; set; } = "";
    public string NidNumber { get; set; } = "";
    public DateTime? DateOfBirth { get; set; }
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string ConfirmPassword { get; set; } = "";
}

public class VerificationViewModel
{
    public string NidNumber { get; set; } = "";
    public string FullName { get; set; } = "";
    public DateTime? DateOfBirth { get; set; }
    public string FatherName { get; set; } = "";
    public string MotherName { get; set; } = "";
    public string PermanentAddress { get; set; } = "";
    public string PresentAddress { get; set; } = "";
    public string PhoneNumber { get; set; } = "";
}

public class PropertyFormModel
{
    public string Title { get; set; } = "";
    public string Type { get; set; } = "residential";
    public string? AddressLine { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? PostalCode { get; set; }
    public decimal? AreaSqft { get; set; }
    public bool IsAvailableForRent { get; set; }
    public decimal? RentPrice { get; set; }
    public decimal? AssessedValue { get; set; }
    public string? LandUse { get; set; }
    public string? Description { get; set; }
}

public class ComplaintFormModel
{
    public string Subject { get; set; } = "";
    public string? Category { get; set; }
    public string Description { get; set; } = "";
    public long? PropertyId { get; set; }
    public IFormFile? Attachment { get; set; }
}

public class TaxCreateModel
{
    public long PropertyId { get; set; }
    public string FiscalYear { get; set; } = "2026-2027";
    public decimal? AssessedValue { get; set; }
}