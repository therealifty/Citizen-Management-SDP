using Citizen_Management.Data;
using Citizen_Management.Models;
using Microsoft.EntityFrameworkCore;
namespace Citizen_Management.Services;
public class TaxAssessmentService {
    private readonly ApplicationDbContext _db; private readonly IConfiguration _cfg;
    public TaxAssessmentService(ApplicationDbContext db,IConfiguration cfg){_db=db;_cfg=cfg;}
    public async Task<TaxAssessment> GenerateAsync(Property p,string fiscalYear,decimal? assessed=null){
        if(p.OwnerId is null) throw new InvalidOperationException("Property requires an owner.");
        var value=assessed ?? p.AssessedValue ?? 0m;
        var land=p.LandUse ?? p.Type ?? "residential";
        var rate=_cfg.GetValue<decimal?>($"Tax:Rates:{land}") ?? _cfg.GetValue<decimal>("Tax:DefaultRate",0.01m);
        var item=await _db.TaxAssessments.FirstOrDefaultAsync(x=>x.PropertyId==p.Id&&x.FiscalYear==fiscalYear);
        if(item==null){item=new TaxAssessment{PropertyId=p.Id,FiscalYear=fiscalYear};_db.TaxAssessments.Add(item);}
        item.OwnerId=p.OwnerId.Value; item.AssessedValueSnapshot=value; item.LandUseSnapshot=land; item.TaxRate=rate; item.TaxAmount=Math.Round(value*rate,2); item.Status="draft";
        var year=int.Parse(fiscalYear[..4]); item.DueDate=new DateTime(year,_cfg.GetValue("Tax:DueMonth",6),_cfg.GetValue("Tax:DueDay",30));
        await _db.SaveChangesAsync(); return item;
    }
}