using Citizen_Management.Data;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Services;

public class RevenueDashboardService
{
    private readonly ApplicationDbContext _db;

    public RevenueDashboardService(ApplicationDbContext db) => _db = db;

    public async Task<RevenueKpi> GetKpisAsync()
    {
        var issued = await _db.TaxAssessments
            .Where(x => x.IssuedAt != null)
            .SumAsync(x => (decimal?)x.TaxAmount) ?? 0;

        var collected = await _db.TaxPayments
            .SumAsync(x => (decimal?)x.Amount) ?? 0;

        var outstanding = Math.Max(issued - collected, 0);

        return new RevenueKpi(
            issued,
            collected,
            outstanding,
            issued > 0 ? Math.Round(collected / issued * 100, 1) : 0
        );
    }

    public async Task<List<MonthlyRevenue>> GetMonthlyAsync(int months = 6)
    {
        var now = DateTime.UtcNow;
        // Explicitly set DateTimeKind.Utc
        var start = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc).AddMonths(-(months - 1));

        var a = await _db.TaxAssessments
            .Where(x => x.IssuedAt >= start)
            .ToListAsync();

        var p = await _db.TaxPayments
            .Where(x => x.PaidAt >= start)
            .ToListAsync();

        return Enumerable.Range(0, months).Select(i =>
        {
            var d = start.AddMonths(i);
            return new MonthlyRevenue(
                d.ToString("MMM yyyy"),
                a.Where(x => x.IssuedAt?.Year == d.Year && x.IssuedAt?.Month == d.Month).Sum(x => x.TaxAmount),
                p.Where(x => x.PaidAt?.Year == d.Year && x.PaidAt?.Month == d.Month).Sum(x => x.Amount)
            );
        }).ToList();
    }
}

public record RevenueKpi(decimal Issued, decimal Collected, decimal Outstanding, decimal CollectionRate);
public record MonthlyRevenue(string Label, decimal Issued, decimal Collected);