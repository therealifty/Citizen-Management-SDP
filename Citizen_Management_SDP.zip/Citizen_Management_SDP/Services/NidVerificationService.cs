using Citizen_Management.Data;
using Citizen_Management.Models;
using Microsoft.EntityFrameworkCore;
namespace Citizen_Management.Services;
public class NidVerificationService {
    private readonly ApplicationDbContext _db; public NidVerificationService(ApplicationDbContext db)=>_db=db;
    public async Task<FakeNid?> FindAsync(string nid)=>await _db.FakeNids.FirstOrDefaultAsync(x=>x.Nid==nid);
    public async Task<bool> MarkVerifiedAsync(string nid,long userId){var n=await FindAsync(nid);if(n==null||n.IsBlocked||n.IsVerified)return false;n.IsVerified=true;n.VerifiedAt=DateTime.UtcNow;n.VerifiedBy=userId;await _db.SaveChangesAsync();return true;}
}