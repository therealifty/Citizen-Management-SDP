using Citizen_Management.Data;using Microsoft.EntityFrameworkCore;
namespace Citizen_Management.Services;
public class OverdueAssessmentService{
 private readonly ApplicationDbContext _db;public OverdueAssessmentService(ApplicationDbContext db)=>_db=db;
 public async Task<int> FlagAsync(bool dryRun=false){var today=DateTime.UtcNow.Date;var list=await _db.TaxAssessments.Include(x=>x.Payments).Where(x=>x.Status=="issued"&&x.DueDate!=null&&x.DueDate<today).ToListAsync();var count=0;foreach(var a in list){if(a.TaxAmount-a.Payments.Sum(p=>p.Amount)<=0)continue;count++;if(!dryRun)a.Status="overdue";}if(!dryRun)await _db.SaveChangesAsync();return count;}
}