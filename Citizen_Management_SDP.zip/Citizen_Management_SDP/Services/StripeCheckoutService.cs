using Citizen_Management.Models;
using Stripe;
using Stripe.Checkout;
namespace Citizen_Management.Services;
public class StripeCheckoutService {
    private readonly IConfiguration _cfg; public StripeCheckoutService(IConfiguration cfg)=>_cfg=cfg;
    public async Task<Session?> CreatePaymentSessionAsync(TaxAssessment a,User u){
        var key=_cfg["Stripe:SecretKey"]; if(string.IsNullOrWhiteSpace(key)) return null;
        StripeConfiguration.ApiKey=key;
        var options=new SessionCreateOptions{Mode="payment",SuccessUrl=_cfg["Stripe:SuccessUrl"],CancelUrl=_cfg["Stripe:CancelUrl"],CustomerEmail=u.Email,Metadata=new Dictionary<string,string>{{"assessment_id",a.Id.ToString()},{"user_id",u.Id.ToString()}},LineItems=new List<SessionLineItemOptions>{new(){PriceData=new SessionLineItemPriceDataOptions{Currency=(_cfg["Stripe:Currency"]??"bdt").ToLower(),UnitAmount=(long)Math.Round(a.TaxAmount*100),ProductData=new SessionLineItemPriceDataProductDataOptions{Name=$"Property Tax {a.FiscalYear}",Description=a.Property?.Title}},Quantity=1}}};
        return await new SessionService().CreateAsync(options);
    }
}