using Citizen_Management.Data;
using Citizen_Management.Models;
using Citizen_Management.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "citizen")]
public class PropertyController : BaseController
{
    public PropertyController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/citizen/properties")]
    public async Task<IActionResult> Index(string? q, bool rent_only = false)
    {
        var query = Db.Properties.Include(x => x.Owner).Where(x => x.IsActive);
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(x => x.Title.Contains(q) || (x.City != null && x.City.Contains(q)));
        if (rent_only)
            query = query.Where(x => x.IsAvailableForRent);

        ViewBag.Owned = await Db.Properties.Where(x => x.OwnerId == CurrentUserId).ToListAsync();

        return View("~/Views/layouts/citizen/properties/index.cshtml", await query.OrderByDescending(x => x.Id).ToListAsync());
    }

    [HttpGet("/citizen/properties/{id:long}")]
    public async Task<IActionResult> Show(long id)
    {
        var p = await Db.Properties.Include(x => x.Owner).FirstOrDefaultAsync(x => x.Id == id);
        return p == null ? NotFound() : View("~/Views/layouts/citizen/properties/show.cshtml", p);
    }

    [HttpGet("/citizen/properties/request/add")]
    public IActionResult Add() => View("~/Views/layouts/citizen/properties/requests/add.cshtml", new PropertyFormModel());

    [HttpPost("/citizen/properties/request/add")]
    public async Task<IActionResult> Add(PropertyFormModel m)
    {
        if (!ModelState.IsValid)
            return View("~/Views/layouts/citizen/properties/requests/add.cshtml", m);

        Db.PropertyRequests.Add(new PropertyRequest
        {
            UserId = CurrentUserId!.Value,
            Type = "add",
            Payload = System.Text.Json.JsonSerializer.Serialize(m)
        });
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("/citizen/properties/{id:long}/request/update")]
    public async Task<IActionResult> Update(long id)
    {
        var p = await Db.Properties.FindAsync(id);
        if (p == null || p.OwnerId != CurrentUserId) return Forbid();
        return View("~/Views/layouts/citizen/properties/requests/update.cshtml", p);
    }

    [HttpPost("/citizen/properties/{id:long}/request/update")]
    public async Task<IActionResult> Update(long id, PropertyFormModel m)
    {
        var p = await Db.Properties.FindAsync(id);
        if (p == null || p.OwnerId != CurrentUserId) return Forbid();

        Db.PropertyRequests.Add(new PropertyRequest
        {
            UserId = CurrentUserId!.Value,
            PropertyId = id,
            Type = "update",
            Payload = System.Text.Json.JsonSerializer.Serialize(m)
        });
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("/citizen/properties/{id:long}/request/transfer")]
    public async Task<IActionResult> Transfer(long id)
    {
        var p = await Db.Properties.FindAsync(id);
        return p == null || p.OwnerId != CurrentUserId ? Forbid() : View("~/Views/layouts/citizen/properties/requests/transfer.cshtml", p);
    }

    [HttpPost("/citizen/properties/{id:long}/request/transfer")]
    public async Task<IActionResult> Transfer(long id, string email)
    {
        var p = await Db.Properties.FindAsync(id);
        if (p == null || p.OwnerId != CurrentUserId) return Forbid();

        var u = await Db.Users.FirstOrDefaultAsync(x => x.Email == email);
        if (u == null)
        {
            ModelState.AddModelError("", "Citizen not found.");
            return View("~/Views/layouts/citizen/properties/requests/transfer.cshtml", p);
        }

        Db.PropertyRequests.Add(new PropertyRequest
        {
            UserId = CurrentUserId!.Value,
            PropertyId = id,
            Type = "transfer",
            Payload = System.Text.Json.JsonSerializer.Serialize(new { email })
        });
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/citizen/properties/{id:long}/rental-request")]
    public async Task<IActionResult> Rental(long id, string? message, decimal? TenantMonthlyRent, decimal? TenantSecurityDeposit)
    {
        var p = await Db.Properties.FindAsync(id);
        if (p == null || !p.IsAvailableForRent) return NotFound();

        var rent = TenantMonthlyRent ?? p.RentPrice ?? 0m;
        var deposit = TenantSecurityDeposit ?? rent; // Default security deposit to 1 month rent or 0

        Db.RentalRequests.Add(new RentalRequest
        {
            PropertyId = id,
            UserId = CurrentUserId!.Value,
            Message = message,
            TenantMonthlyRent = rent,
            OwnerMonthlyRent = rent,
            TenantSecurityDeposit = deposit,
            OwnerSecurityDeposit = deposit
        });
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("/citizen/rental-requests/{id:long}/owner-confirm")]
    public async Task<IActionResult> ConfirmRental(long id)
    {
        var r = await Db.RentalRequests.Include(x => x.Property).FirstOrDefaultAsync(x => x.Id == id);
        if (r == null || r.Property == null || r.Property.OwnerId != CurrentUserId)
        {
            return Forbid();
        }

        r.ReadyForAdmin = true;
        r.OwnerConfirmedAt = DateTime.UtcNow;
        r.OwnerConfirmedBy = CurrentUserId;
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
}