using Citizen_Management.Data;
using Citizen_Management.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "citizen")]
public class VerificationController : BaseController
{
    public VerificationController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/verification/apply")]
    public async Task<IActionResult> Apply(string? nid)
    {
        if (string.IsNullOrWhiteSpace(nid))
        {
            return View("~/Views/verification/apply.cshtml");
        }

        var cleanNid = nid.Trim();
        var record = await Db.FakeNids.FirstOrDefaultAsync(x => x.Nid == cleanNid);

        if (record == null)
        {
            // Transient object for the view; do NOT add/save to DB yet
            record = new FakeNid
            {
                Nid = cleanNid,
                Name = CurrentUser?.Name ?? string.Empty,
                DateOfBirth = DateTime.SpecifyKind(new DateTime(2000, 1, 1), DateTimeKind.Utc)
            };
        }

        ViewBag.FoundNid = record;
        return View("~/Views/verification/apply.cshtml", record);
    }

    [HttpPost("/verification/apply")]
    public async Task<IActionResult> Apply(string nidNumber, string? fullName, DateTime? dateOfBirth, string? phone)
    {
        if (string.IsNullOrWhiteSpace(nidNumber))
        {
            ModelState.AddModelError("", "Please enter a valid NID number.");
            return View("~/Views/verification/apply.cshtml");
        }

        var cleanNid = nidNumber.Trim();
        var finalName = !string.IsNullOrWhiteSpace(fullName) && fullName != "User Name"
            ? fullName.Trim()
            : (CurrentUser?.Name ?? "Verified Citizen");

        var finalDob = dateOfBirth.HasValue
            ? DateTime.SpecifyKind(dateOfBirth.Value.Date, DateTimeKind.Utc)
            : DateTime.SpecifyKind(new DateTime(2000, 1, 1), DateTimeKind.Utc);

        var record = await Db.FakeNids.FirstOrDefaultAsync(x => x.Nid == cleanNid);

        if (record == null)
        {
            record = new FakeNid
            {
                Nid = cleanNid,
                Name = finalName,
                DateOfBirth = finalDob
            };
            Db.FakeNids.Add(record);
        }
        else
        {
            record.Name = finalName;
            record.DateOfBirth = finalDob;
        }

        // Attach verified NID directly to current user
        var user = await Db.Users.FindAsync(CurrentUserId);
        if (user != null)
        {
            user.NidNumber = cleanNid;
            user.Name = finalName;
        }

        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Status));
    }

    [HttpGet("/verification/status")]
    public async Task<IActionResult> Status()
    {
        var user = await Db.Users.FirstOrDefaultAsync(x => x.Id == CurrentUserId);
        return View("~/Views/verification/status.cshtml", user);
    }
}