using Citizen_Management.Data;
using Citizen_Management.Models;
using Citizen_Management.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "citizen")]
public class ComplaintController : BaseController
{
    public ComplaintController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/citizen/complaints")]
    public async Task<IActionResult> Index() =>
        View("~/Views/layouts/citizen/complaints/index.cshtml",
            await Db.Complaints.Include(x => x.Property).Where(x => x.UserId == CurrentUserId).OrderByDescending(x => x.Id).ToListAsync());

    [HttpGet("/citizen/complaints/create")]
    public async Task<IActionResult> Create()
    {
        ViewBag.Properties = await Db.Properties.Where(x => x.OwnerId == CurrentUserId).ToListAsync();
        return View("~/Views/layouts/citizen/complaints/create.cshtml", new ComplaintFormModel());
    }

    [HttpPost("/citizen/complaints/create")]
    public async Task<IActionResult> Create(ComplaintFormModel m)
    {
        if (!ModelState.IsValid)
            return View("~/Views/layouts/citizen/complaints/create.cshtml", m);

        var c = new Complaint
        {
            UserId = CurrentUserId!.Value,
            PropertyId = m.PropertyId,
            Subject = m.Subject,
            Category = m.Category,
            Description = m.Description
        };

        if (m.Attachment != null)
        {
            var dir = Path.Combine(Environment.CurrentDirectory, "wwwroot", "uploads", "complaints");
            Directory.CreateDirectory(dir);
            var file = Guid.NewGuid() + Path.GetExtension(m.Attachment.FileName);
            using var s = System.IO.File.Create(Path.Combine(dir, file));
            await m.Attachment.CopyToAsync(s);
            c.AttachmentPath = "/uploads/complaints/" + file;
        }

        Db.Complaints.Add(c);
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("/citizen/complaints/{id:long}")]
    public async Task<IActionResult> Show(long id)
    {
        var c = await Db.Complaints.Include(x => x.Property).FirstOrDefaultAsync(x => x.Id == id && x.UserId == CurrentUserId);
        return c == null ? NotFound() : View("~/Views/layouts/citizen/complaints/show.cshtml", c);
    }
}