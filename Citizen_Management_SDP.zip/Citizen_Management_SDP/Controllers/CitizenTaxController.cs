using Citizen_Management.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "citizen")]
public class CitizenTaxController : BaseController
{
    public CitizenTaxController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/citizen/taxes")]
    public async Task<IActionResult> Index() =>
        View("~/Views/layouts/citizen/taxes/index.cshtml",
            await Db.TaxAssessments
                .Include(x => x.Property)
                .Include(x => x.Payments)
                .Where(x => x.OwnerId == CurrentUserId)
                .OrderByDescending(x => x.FiscalYear)
                .ToListAsync());

    [HttpGet("/citizen/taxes/{id:long}/pay")]
    [HttpGet("/citizen/taxes/pay/{id:long}")]
    public async Task<IActionResult> Pay(long id)
    {
        var a = await Db.TaxAssessments
            .Include(x => x.Property)
            .Include(x => x.Payments)
            .FirstOrDefaultAsync(x => x.Id == id && x.OwnerId == CurrentUserId);

        return a == null ? NotFound() : View("~/Views/layouts/citizen/taxes/pay.cshtml", a);
    }

    [HttpPost("/citizen/taxes/{id:long}/pay")]
    [HttpPost("/citizen/taxes/pay/{id:long}")]
    public async Task<IActionResult> Pay(long id, decimal amount)
    {
        var a = await Db.TaxAssessments
            .Include(x => x.Payments)
            .FirstOrDefaultAsync(x => x.Id == id && x.OwnerId == CurrentUserId);

        if (a == null) return NotFound();

        if (amount <= 0)
            amount = a.TaxAmount - a.Payments.Sum(x => x.Amount);

        Db.TaxPayments.Add(new Models.TaxPayment
        {
            TaxAssessmentId = id,
            PayerId = CurrentUserId,
            RecordedBy = CurrentUserId,
            Amount = amount,
            Method = "online_demo",
            Reference = "DEMO-" + Guid.NewGuid().ToString("N")[..10],
            PaidAt = DateTime.UtcNow
        });

        await Db.SaveChangesAsync();

        a = await Db.TaxAssessments.Include(x => x.Payments).FirstAsync(x => x.Id == id);
        a.MarkPaidIfSettled();
        await Db.SaveChangesAsync();

        return RedirectToAction(nameof(Index));
    }

    [HttpGet("/citizen/taxes/payments/{id:long}/receipt")]
    [HttpGet("/citizen/taxes/receipt/{id:long}")]
    public async Task<IActionResult> Receipt(long id)
    {
        var p = await Db.TaxPayments
            .Include(x => x.Assessment)
            .ThenInclude(x => x!.Property)
            .FirstOrDefaultAsync(x => (x.Id == id || x.TaxAssessmentId == id) && x.PayerId == CurrentUserId);

        return p == null ? NotFound() : View("~/Views/layouts/citizen/taxes/receipt.cshtml", p);
    }
}