using Citizen_Management.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "citizen")]
public class CitizenRentAgreementController : BaseController
{
    public CitizenRentAgreementController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/citizen/rent-agreements")]
    public async Task<IActionResult> Index() =>
        View("~/Views/layouts/citizen/rent-agreements/index.cshtml",
            await Db.RentAgreements
                .Include(x => x.Property)
                .Include(x => x.Landlord)
                .Include(x => x.Tenant)
                .Where(x => x.TenantId == CurrentUserId || x.LandlordId == CurrentUserId)
                .OrderByDescending(x => x.StartDate)
                .ToListAsync());

    [HttpGet("/citizen/rent-agreements/{id:long}")]
    public async Task<IActionResult> Show(long id)
    {
        var a = await Db.RentAgreements
            .Include(x => x.Property)
            .Include(x => x.Landlord)
            .Include(x => x.Tenant)
            .FirstOrDefaultAsync(x => x.Id == id);

        return a == null || (a.TenantId != CurrentUserId && a.LandlordId != CurrentUserId)
            ? Forbid()
            : View("~/Views/layouts/citizen/rent-agreements/show.cshtml", a);
    }
}