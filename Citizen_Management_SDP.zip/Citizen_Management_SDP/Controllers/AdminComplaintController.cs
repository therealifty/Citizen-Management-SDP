using Citizen_Management.Data;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;
namespace Citizen_Management.Controllers;
[Authorize(Roles="admin")]public class AdminComplaintController:BaseController{
 public AdminComplaintController(ApplicationDbContext db):base(db){}
 [HttpGet("/admin/complaints")]public async Task<IActionResult>Index()=>View("~/Views/admin/complaints/index.cshtml",await Db.Complaints.Include(x=>x.User).Include(x=>x.Property).OrderByDescending(x=>x.Id).ToListAsync());
 [HttpGet("/admin/complaints/{id:long}")]public async Task<IActionResult>Show(long id)=>View("~/Views/admin/complaints/show.cshtml",await Db.Complaints.Include(x=>x.User).Include(x=>x.Property).FirstOrDefaultAsync(x=>x.Id==id));
 [HttpPost("/admin/complaints/{id:long}")]public async Task<IActionResult>Update(long id,string status,string? reply){var c=await Db.Complaints.FindAsync(id);if(c==null)return NotFound();c.Status=status;c.AdminReply=reply;if(status=="resolved"){c.ResolvedAt=DateTime.UtcNow;c.ResolvedBy=CurrentUserId;}await Db.SaveChangesAsync();return RedirectToAction(nameof(Show),new{id});}
}