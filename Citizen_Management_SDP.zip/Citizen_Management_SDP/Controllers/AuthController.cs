using Citizen_Management.Data;
using Citizen_Management.Models;
using Citizen_Management.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

public class AuthController : BaseController
{
    private readonly IPasswordHasher<User> _hasher;

    public AuthController(ApplicationDbContext db, IPasswordHasher<User> hasher) : base(db) => _hasher = hasher;

    [HttpGet("/login")]
    public IActionResult Login() => View("login");

    [HttpGet("/register")]
    public IActionResult Register() => View("register");

    [HttpPost("/register")]
    public async Task<IActionResult> Register(RegisterViewModel m)
    {
        if (!ModelState.IsValid || m.Password != m.ConfirmPassword)
        {
            ModelState.AddModelError("", "Passwords must match and required fields cannot be empty.");
            return View("register", m);
        }

        if (await Db.Users.AnyAsync(x => x.Email == m.Email))
        {
            ModelState.AddModelError("Email", "Email is already registered.");
            return View("register", m);
        }

        var legalName = !string.IsNullOrWhiteSpace(m.FullName) ? m.FullName.Trim() : "Citizen User";

        var u = new User
        {
            Email = m.Email.Trim(),
            Name = legalName,
            FullName = legalName,
            Role = "citizen",
            VerificationStatus = "Verified"
        };

        if (!string.IsNullOrWhiteSpace(m.NidNumber))
        {
            u.NidNumber = m.NidNumber.Trim();
        }

        if (m.DateOfBirth.HasValue)
        {
            u.DateOfBirth = m.DateOfBirth.Value;
        }

        u.PasswordHash = _hasher.HashPassword(u, m.Password);

        Db.Users.Add(u);
        await Db.SaveChangesAsync();

        await SignIn(u, false);
        return RedirectToAction("Profile", "Citizen");
    }

    [HttpPost("/login")]
    public async Task<IActionResult> Login(LoginViewModel m)
    {
        var u = await Db.Users.FirstOrDefaultAsync(x => x.Email == m.Email);
        if (u == null || _hasher.VerifyHashedPassword(u, u.PasswordHash, m.Password) == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError("", "Invalid email or password.");
            return View("login", m);
        }

        await SignIn(u, m.Remember);
        return u.IsAdmin() ? RedirectToAction("Dashboard", "Admin") : RedirectToAction("Dashboard", "Citizen");
    }

    [HttpPost("/logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Login");
    }

    [HttpGet("/access-denied")]
    public IActionResult AccessDenied() => View("~/Views/Auth/AccessDenied.cshtml");

    private async Task SignIn(User u, bool remember)
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, u.Id.ToString()),
            new Claim(ClaimTypes.Name, u.FullName ?? u.Name ?? u.DisplayName),
            new Claim(ClaimTypes.Email, u.Email),
            new Claim(ClaimTypes.Role, u.Role)
        };

        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme)),
            new AuthenticationProperties { IsPersistent = remember });
    }
}