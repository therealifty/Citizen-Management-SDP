using Citizen_Management.Data;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;
namespace Citizen_Management.Controllers.Api;
[ApiController][Route("api/nid")]public class FakeNidStatusController:ControllerBase{
 private readonly ApplicationDbContext _db;public FakeNidStatusController(ApplicationDbContext db)=>_db=db;
 [HttpGet("{nidNumber}")]public async Task<IActionResult>Show(string nidNumber){var n=await _db.FakeNids.FirstOrDefaultAsync(x=>x.Nid==nidNumber);if(n==null)return NotFound(new{nid=nidNumber,status="not_found"});var status=n.IsBlocked?"blocked":n.IsVerified?"already_verified":"available";return Ok(new{nid=n.Nid,status,message=status=="blocked"?n.Reason:"NID status checked"});}
}