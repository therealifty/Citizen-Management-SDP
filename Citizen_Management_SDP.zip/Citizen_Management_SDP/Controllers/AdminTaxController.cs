using Citizen_Management.Data;
using Citizen_Management.Models;
using Citizen_Management.Services;
using Citizen_Management.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "admin")]
public class AdminTaxController : BaseController
{
    private readonly TaxAssessmentService _tax;

    public AdminTaxController(ApplicationDbContext db, TaxAssessmentService tax) : base(db) => _tax = tax;

    [HttpGet("/admin/taxes")]
    public async Task<IActionResult> Index() =>
        View("~/Views/admin/taxes/index.cshtml", await Db.TaxAssessments
            .Include(x => x.Property)
            .Include(x => x.Owner)
            .OrderByDescending(x => x.Id)
            .ToListAsync());

    [HttpGet("/admin/taxes/create")]
    [HttpGet("/admin/taxes/generate")]
    public IActionResult Create() =>
        View("~/Views/admin/taxes/create.cshtml", new TaxCreateModel());

    [HttpPost("/admin/taxes/create")]
    [HttpPost("/admin/taxes/generate")]
    public async Task<IActionResult> Create(TaxCreateModel m)
    {
        var p = await Db.Properties.FindAsync(m.PropertyId);
        if (p == null) return NotFound();

        await _tax.GenerateAsync(p, m.FiscalYear, m.AssessedValue);
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("/admin/taxes/{id:long}")]
    public async Task<IActionResult> Show(long id) =>
        View("~/Views/admin/taxes/show.cshtml", await Db.TaxAssessments
            .Include(x => x.Property)
            .Include(x => x.Payments)
            .FirstOrDefaultAsync(x => x.Id == id));

    [HttpPost("/admin/taxes/{id:long}/issue")]
    public async Task<IActionResult> Issue(long id)
    {
        var a = await Db.TaxAssessments.FindAsync(id);
        if (a == null) return NotFound();

        a.Status = "issued";
        a.IssuedAt = DateTime.UtcNow;
        a.DueDate ??= DateTime.UtcNow.Date.AddMonths(1);
        await Db.SaveChangesAsync();

        return RedirectToAction(nameof(Show), new { id });
    }

    [HttpPost("/admin/taxes/{id:long}/payments")]
    public async Task<IActionResult> Payment(long id, decimal amount, string method = "cash", string? reference = null)
    {
        var a = await Db.TaxAssessments.FindAsync(id);
        if (a == null) return NotFound();

        Db.TaxPayments.Add(new TaxPayment
        {
            TaxAssessmentId = id,
            PayerId = a.OwnerId,
            RecordedBy = CurrentUserId,
            Amount = amount,
            Method = method,
            Reference = reference,
            PaidAt = DateTime.UtcNow
        });

        await Db.SaveChangesAsync();

        a = await Db.TaxAssessments.Include(x => x.Payments).FirstAsync(x => x.Id == id);
        a.MarkPaidIfSettled();
        await Db.SaveChangesAsync();

        return RedirectToAction(nameof(Show), new { id });
    }
}