using Citizen_Management.Data;
using Citizen_Management.Models;
using Microsoft.AspNetCore.Mvc;
namespace Citizen_Management.Controllers;
public abstract class BaseController:Controller {
    protected readonly ApplicationDbContext Db;
    protected BaseController(ApplicationDbContext db)=>Db=db;
    protected long? CurrentUserId => long.TryParse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value,out var id)?id:null;
    protected User? CurrentUser => CurrentUserId.HasValue?Db.Users.Find(CurrentUserId.Value):null;
    protected IActionResult ForbidIf(bool condition)=>condition?Forbid():null!;
}