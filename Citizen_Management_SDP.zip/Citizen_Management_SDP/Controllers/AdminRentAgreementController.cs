using Citizen_Management.Data;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;
namespace Citizen_Management.Controllers;
[Authorize(Roles="admin")]public class AdminRentAgreementController:BaseController{
 public AdminRentAgreementController(ApplicationDbContext db):base(db){}
 [HttpGet("/admin/rent-agreements")]public async Task<IActionResult>Index()=>View("~/Views/admin/rent-agreements/index.cshtml",await Db.RentAgreements.Include(x=>x.Property).Include(x=>x.Landlord).Include(x=>x.Tenant).ToListAsync());
 [HttpGet("/admin/rent-agreements/{id:long}")]public async Task<IActionResult>Show(long id)=>View("~/Views/admin/rent-agreements/show.cshtml",await Db.RentAgreements.Include(x=>x.Property).Include(x=>x.Landlord).Include(x=>x.Tenant).FirstOrDefaultAsync(x=>x.Id==id));
}