using System.Security.Claims;
using Citizen_Management.Data;
using Citizen_Management.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "citizen")]
public class CitizenController : BaseController
{
    public CitizenController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/citizen/dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        ViewBag.PropertiesCount = await Db.Properties.CountAsync(p => p.OwnerId == CurrentUserId);
        ViewBag.AssessmentsCount = await Db.TaxAssessments.CountAsync(t => t.OwnerId == CurrentUserId);
        ViewBag.ComplaintsCount = await Db.Complaints.CountAsync(c => c.UserId == CurrentUserId);

        return View("~/Views/dashboard/normalcitizenn.cshtml");
    }

    [HttpGet("/citizen/profile")]
    public async Task<IActionResult> Profile()
    {
        var emailClaim = User.FindFirst(ClaimTypes.Email)?.Value ?? User.Identity?.Name;

        var user = (CurrentUserId.HasValue
            ? await Db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == CurrentUserId.Value)
            : null)
            ?? await Db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Email == emailClaim || u.Email == "citizen@citizen.local");

        if (user == null)
        {
            return RedirectToAction("Login", "Auth");
        }

        return View("~/Views/dashboard/citizenprofile.cshtml", user);
    }

    [HttpPost("/citizen/profile")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(
        string? FullName,
        string? name,
        DateTime? DateOfBirth,
        string? Phone,
        string? EmergencyContact,
        string? PresentAddress,
        string? PermanentAddress,
        IFormFile? profileImage,
        IFormFile? PassportPhotoFile)
    {
        var emailClaim = User.FindFirst(ClaimTypes.Email)?.Value ?? User.Identity?.Name;

        var user = (CurrentUserId.HasValue
            ? await Db.Users.FirstOrDefaultAsync(u => u.Id == CurrentUserId.Value)
            : null)
            ?? await Db.Users.FirstOrDefaultAsync(u => u.Email == emailClaim || u.Email == "citizen@citizen.local");

        if (user != null)
        {
            // Sync both FullName and Name
            var updatedName = !string.IsNullOrWhiteSpace(FullName) ? FullName : name;
            if (!string.IsNullOrWhiteSpace(updatedName))
            {
                user.FullName = updatedName.Trim();
                user.Name = updatedName.Trim();
            }

            // Update Civil & Contact Data
            if (DateOfBirth.HasValue) user.DateOfBirth = DateOfBirth.Value;
            if (!string.IsNullOrWhiteSpace(Phone)) user.Phone = Phone.Trim();
            if (!string.IsNullOrWhiteSpace(PresentAddress)) user.PresentAddress = PresentAddress.Trim();
            if (!string.IsNullOrWhiteSpace(PermanentAddress)) user.PermanentAddress = PermanentAddress.Trim();

            // Persist Emergency Contact (via direct property or reflection fallback if model lacks it)
            if (!string.IsNullOrWhiteSpace(EmergencyContact))
            {
                var ecProp = typeof(User).GetProperty("EmergencyContact");
                if (ecProp != null && ecProp.CanWrite)
                {
                    ecProp.SetValue(user, EmergencyContact.Trim());
                }
            }

            // Accept and store uploaded avatar
            var uploadedFile = profileImage ?? PassportPhotoFile;
            if (uploadedFile != null && uploadedFile.Length > 0)
            {
                var folder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "avatars");
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                var ext = Path.GetExtension(uploadedFile.FileName).ToLowerInvariant();
                var fileName = $"avatar_{user.Id}_{DateTime.UtcNow.Ticks}{ext}";
                var filePath = Path.Combine(folder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await uploadedFile.CopyToAsync(stream);
                }

                user.PassportPhoto = $"/uploads/avatars/{fileName}";
            }

            await Db.SaveChangesAsync();
            TempData["SuccessMessage"] = "Profile and credentials updated successfully!";
        }

        return RedirectToAction(nameof(Profile));
    }
}