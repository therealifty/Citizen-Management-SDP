using Citizen_Management.Data;
using Citizen_Management.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "admin")]
public class AdminRevenueController : BaseController
{
    private readonly RevenueDashboardService _service;

    public AdminRevenueController(ApplicationDbContext db, RevenueDashboardService service)
        : base(db)
    {
        _service = service;
    }

    [HttpGet("/admin/revenue")]
    public async Task<IActionResult> Index()
    {
        ViewBag.Kpi = await _service.GetKpisAsync();
        ViewBag.Monthly = await _service.GetMonthlyAsync();
        return View("~/Views/admin/revenue/index.cshtml");
    }

    [HttpGet("/admin/revenue/export")]
    public async Task<IActionResult> Export()
    {
        var rows = await Db.TaxPayments
            .Include(x => x.Assessment)
            .ToListAsync();

        var sb = new StringBuilder("Id,Assessment,Amount,Method,Reference,PaidAt\n");

        foreach (var x in rows)
        {
            sb.AppendLine(
                $"{x.Id},{x.Assessment?.FiscalYear},{x.Amount},{Csv(x.Method)},{Csv(x.Reference)},{x.PaidAt:O}");
        }

        return File(
            Encoding.UTF8.GetBytes(sb.ToString()),
            "text/csv",
            "tax-payments.csv");
    }

    [HttpGet("/admin/revenue/export-valuations")]
    public async Task<IActionResult> ExportValuations()
    {
        var rows = await Db.Properties.ToListAsync();
        var sb = new StringBuilder("Id,Title,AssessedValue,LandUse\n");

        foreach (var x in rows)
        {
            sb.AppendLine(
                $"{x.Id},{Csv(x.Title)},{x.AssessedValue},{Csv(x.LandUse)}");
        }

        return File(
            Encoding.UTF8.GetBytes(sb.ToString()),
            "text/csv",
            "property-valuations.csv");
    }

    private static string Csv(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return "";

        return $"\"{value.Replace("\"", "\"\"")}\"";
    }
}
