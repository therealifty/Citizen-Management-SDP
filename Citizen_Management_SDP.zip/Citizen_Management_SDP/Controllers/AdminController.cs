using Citizen_Management.Data;
using Citizen_Management.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Controllers;

[Authorize(Roles = "admin")]
public class AdminController : BaseController
{
    public AdminController(ApplicationDbContext db) : base(db) { }

    [HttpGet("/admin/dashboard")]
    public IActionResult Dashboard()
    {
        return View("~/Views/dashboard/admindashboard.cshtml");
    }

    [HttpGet("/admin/verification")]
    public async Task<IActionResult> VerificationList()
    {
        var citizens = await Db.Users
            .Where(u => u.Role == "citizen" || string.IsNullOrEmpty(u.Role))
            .OrderByDescending(u => u.Id)
            .ToListAsync();

        return View("~/Views/admin/verification/index.cshtml", citizens);
    }

    [HttpPost("/admin/verification/toggle")]
    public async Task<IActionResult> ToggleVerification(long userId)
    {
        var user = await Db.Users.FindAsync(userId);
        if (user != null)
        {
            if (!string.IsNullOrEmpty(user.NidNumber))
            {
                user.NidNumber = null;
            }
            else
            {
                user.NidNumber = "VERIFIED-" + DateTime.UtcNow.Ticks.ToString().Substring(10);
            }
            await Db.SaveChangesAsync();
        }
        return RedirectToAction(nameof(VerificationList));
    }
}