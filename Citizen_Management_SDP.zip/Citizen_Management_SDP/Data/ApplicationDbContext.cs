using Citizen_Management.Models;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(
        DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<FakeNid> FakeNids => Set<FakeNid>();
    public DbSet<Property> Properties => Set<Property>();
    public DbSet<PropertyRequest> PropertyRequests => Set<PropertyRequest>();
    public DbSet<RentalRequest> RentalRequests => Set<RentalRequest>();
    public DbSet<RentAgreement> RentAgreements => Set<RentAgreement>();
    public DbSet<TaxAssessment> TaxAssessments => Set<TaxAssessment>();
    public DbSet<TaxPayment> TaxPayments => Set<TaxPayment>();
    public DbSet<Complaint> Complaints => Set<Complaint>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // =========================================================
        // USER
        // =========================================================

        b.Entity<User>()
            .HasIndex(x => x.Email)
            .IsUnique();

        b.Entity<User>()
            .HasIndex(x => x.NidNumber);


        // =========================================================
        // FAKE NID
        // =========================================================

        b.Entity<FakeNid>()
            .HasIndex(x => x.Nid)
            .IsUnique();


        // =========================================================
        // PROPERTY DECIMAL PRECISION
        // =========================================================

        b.Entity<Property>()
            .Property(x => x.AreaSqft)
            .HasPrecision(18, 2);

        b.Entity<Property>()
            .Property(x => x.RentPrice)
            .HasPrecision(12, 2);

        b.Entity<Property>()
            .Property(x => x.AssessedValue)
            .HasPrecision(14, 2);


        // =========================================================
        // PROPERTY RELATIONSHIP
        // =========================================================

        b.Entity<Property>()
            .HasOne(x => x.Owner)
            .WithMany()
            .HasForeignKey(x => x.OwnerId)
            .OnDelete(DeleteBehavior.SetNull);


        // =========================================================
        // PROPERTY REQUEST
        // =========================================================

        b.Entity<PropertyRequest>()
            .HasOne(x => x.User)
            .WithMany()
            .HasForeignKey(x => x.UserId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<PropertyRequest>()
            .HasOne(x => x.Property)
            .WithMany()
            .HasForeignKey(x => x.PropertyId)
            .OnDelete(DeleteBehavior.SetNull);


        // =========================================================
        // RENTAL REQUEST
        // =========================================================

        b.Entity<RentalRequest>()
            .Property(x => x.TenantMonthlyRent)
            .HasPrecision(12, 2);

        b.Entity<RentalRequest>()
            .Property(x => x.OwnerMonthlyRent)
            .HasPrecision(12, 2);

        b.Entity<RentalRequest>()
            .Property(x => x.TenantSecurityDeposit)
            .HasPrecision(12, 2);

        b.Entity<RentalRequest>()
            .Property(x => x.OwnerSecurityDeposit)
            .HasPrecision(12, 2);


        b.Entity<RentalRequest>()
            .HasOne(x => x.Property)
            .WithMany(p => p.RentalRequests)
            .HasForeignKey(x => x.PropertyId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<RentalRequest>()
            .HasOne(x => x.User)
            .WithMany()
            .HasForeignKey(x => x.UserId)
            .OnDelete(DeleteBehavior.NoAction);


        // =========================================================
        // RENT AGREEMENT
        // =========================================================

        b.Entity<RentAgreement>()
            .Property(x => x.MonthlyRent)
            .HasPrecision(12, 2);

        b.Entity<RentAgreement>()
            .Property(x => x.SecurityDeposit)
            .HasPrecision(12, 2);


        // PROPERTY -> RENT AGREEMENT
        b.Entity<RentAgreement>()
            .HasOne(x => x.Property)
            .WithMany(p => p.RentAgreements)
            .HasForeignKey(x => x.PropertyId)
            .OnDelete(DeleteBehavior.NoAction);


        // LANDLORD -> RENT AGREEMENT
        b.Entity<RentAgreement>()
            .HasOne(x => x.Landlord)
            .WithMany()
            .HasForeignKey(x => x.LandlordId)
            .OnDelete(DeleteBehavior.NoAction);


        // TENANT -> RENT AGREEMENT
        // IMPORTANT:
        // NoAction prevents SQL Server multiple cascade path error.
        b.Entity<RentAgreement>()
            .HasOne(x => x.Tenant)
            .WithMany()
            .HasForeignKey(x => x.TenantId)
            .OnDelete(DeleteBehavior.NoAction);


        // =========================================================
        // TAX ASSESSMENT
        // =========================================================

        b.Entity<TaxAssessment>()
            .Property(x => x.AssessedValueSnapshot)
            .HasPrecision(18, 2);

        b.Entity<TaxAssessment>()
            .Property(x => x.TaxRate)
            .HasPrecision(6, 4);

        b.Entity<TaxAssessment>()
            .Property(x => x.TaxAmount)
            .HasPrecision(14, 2);

        b.Entity<TaxAssessment>()
            .HasIndex(x => new
            {
                x.PropertyId,
                x.FiscalYear
            })
            .IsUnique();


        // PROPERTY -> TAX ASSESSMENT
        b.Entity<TaxAssessment>()
            .HasOne(x => x.Property)
            .WithMany(p => p.TaxAssessments)
            .HasForeignKey(x => x.PropertyId)
            .OnDelete(DeleteBehavior.NoAction);


        // OWNER -> TAX ASSESSMENT
        b.Entity<TaxAssessment>()
            .HasOne(x => x.Owner)
            .WithMany()
            .HasForeignKey(x => x.OwnerId)
            .OnDelete(DeleteBehavior.NoAction);


        // =========================================================
        // TAX PAYMENT
        // =========================================================

        b.Entity<TaxPayment>()
            .Property(x => x.Amount)
            .HasPrecision(14, 2);

        b.Entity<TaxPayment>()
            .HasOne(x => x.Assessment)
            .WithMany(a => a.Payments)
            .HasForeignKey(x => x.TaxAssessmentId)
            .OnDelete(DeleteBehavior.Cascade);


        // =========================================================
        // COMPLAINT
        // =========================================================

        b.Entity<Complaint>()
            .HasOne(x => x.User)
            .WithMany()
            .HasForeignKey(x => x.UserId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<Complaint>()
            .HasOne(x => x.Property)
            .WithMany()
            .HasForeignKey(x => x.PropertyId)
            .OnDelete(DeleteBehavior.SetNull);
    }
}