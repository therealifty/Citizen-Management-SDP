using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace Citizen_Management.Data;

public static class PostgresSchemaManager
{
    public static async Task RepairAsync(ApplicationDbContext db)
    {
        await db.Database.EnsureCreatedAsync();
        await using var connection = new NpgsqlConnection(db.Database.GetConnectionString());
        await connection.OpenAsync();

        var sql = """
-- Legacy compatibility: add/rename columns required by the current ASP.NET model.
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='Users' AND column_name='National Id')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='Users' AND column_name='NationalId') THEN
        ALTER TABLE "Users" RENAME COLUMN "National Id" TO "NationalId";
    END IF;
END $$;

ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "Phone" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "NationalId" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "NidNumber" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "FullName" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "DateOfBirth" timestamp with time zone;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "FatherName" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "MotherName" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "PermanentAddress" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "PresentAddress" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "PhoneNumber" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "NidFrontImage" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "NidBackImage" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "PassportPhoto" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "VerificationRequestedAt" timestamp with time zone;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "VerifiedAt" timestamp with time zone;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "VerifiedBy" bigint;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "RejectedAt" timestamp with time zone;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "RejectedBy" bigint;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "RejectionReason" text;
ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "BirthPlace" text;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "PresentAddress" text;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "PermanentAddress" text;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "BloodGroup" text;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "Reason" text;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "IsBlocked" boolean NOT NULL DEFAULT false;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "IsVerified" boolean NOT NULL DEFAULT false;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "VerifiedAt" timestamp with time zone;
ALTER TABLE "FakeNids" ADD COLUMN IF NOT EXISTS "VerifiedBy" bigint;

ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "OwnerId" bigint;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "Title" text NOT NULL DEFAULT 'Property';
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "Type" text NOT NULL DEFAULT 'residential';
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "AddressLine" text;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "City" text;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "State" text;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "PostalCode" text;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "AreaSqft" numeric(18,2);
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "IsActive" boolean NOT NULL DEFAULT true;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "IsAvailableForRent" boolean NOT NULL DEFAULT false;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "RentPrice" numeric(12,2);
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "AssessedValue" numeric(18,2);
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "LandUse" text;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "LastValuationAt" timestamp with time zone;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "Description" text;
ALTER TABLE "Properties" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "Complaints" ADD COLUMN IF NOT EXISTS "Category" text;
ALTER TABLE "Complaints" ADD COLUMN IF NOT EXISTS "AdminReply" text;
ALTER TABLE "Complaints" ADD COLUMN IF NOT EXISTS "AttachmentPath" text;
ALTER TABLE "Complaints" ADD COLUMN IF NOT EXISTS "ResolvedAt" timestamp with time zone;
ALTER TABLE "Complaints" ADD COLUMN IF NOT EXISTS "ResolvedBy" bigint;

ALTER TABLE "PropertyRequests" ADD COLUMN IF NOT EXISTS "PropertyId" bigint;
ALTER TABLE "PropertyRequests" ADD COLUMN IF NOT EXISTS "Payload" text NOT NULL DEFAULT '{}';
ALTER TABLE "PropertyRequests" ADD COLUMN IF NOT EXISTS "DecisionNote" text;
ALTER TABLE "PropertyRequests" ADD COLUMN IF NOT EXISTS "DecidedBy" bigint;
ALTER TABLE "PropertyRequests" ADD COLUMN IF NOT EXISTS "DecidedAt" timestamp with time zone;
ALTER TABLE "PropertyRequests" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "Message" text;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "TenantStartDate" timestamp with time zone;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "TenantEndDate" timestamp with time zone;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "TenantMonthlyRent" numeric(12,2);
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "TenantSecurityDeposit" numeric(12,2);
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerStartDate" timestamp with time zone;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerEndDate" timestamp with time zone;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerMonthlyRent" numeric(12,2);
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerSecurityDeposit" numeric(12,2);
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerNotes" text;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "ReadyForAdmin" boolean NOT NULL DEFAULT false;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerConfirmedAt" timestamp with time zone;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "OwnerConfirmedBy" bigint;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "DecisionNote" text;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "DecidedBy" bigint;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "DecidedAt" timestamp with time zone;
ALTER TABLE "RentalRequests" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "LandUseSnapshot" text;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "DueDate" timestamp with time zone;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "IssuedAt" timestamp with time zone;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "PaidAt" timestamp with time zone;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "Notes" text;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxAssessments' AND column_name='FiscalYear' AND data_type <> 'text') THEN
        ALTER TABLE "TaxAssessments" ALTER COLUMN "FiscalYear" TYPE text USING "FiscalYear"::text;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='PaymentDate')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='PaidAt') THEN
        ALTER TABLE "TaxPayments" RENAME COLUMN "PaymentDate" TO "PaidAt";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='PaymentMethod')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='Method') THEN
        ALTER TABLE "TaxPayments" RENAME COLUMN "PaymentMethod" TO "Method";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='TransactionId')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='Reference') THEN
        ALTER TABLE "TaxPayments" RENAME COLUMN "TransactionId" TO "Reference";
    END IF;
END $$;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "PayerId" bigint;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "RecordedBy" bigint;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "Method" text;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "Reference" text;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "PaidAt" timestamp with time zone;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "Notes" text;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "RentAgreements" ADD COLUMN IF NOT EXISTS "RentalRequestId" bigint;
ALTER TABLE "RentAgreements" ADD COLUMN IF NOT EXISTS "ApprovedBy" bigint;
ALTER TABLE "RentAgreements" ADD COLUMN IF NOT EXISTS "AgreementNumber" text;
ALTER TABLE "RentAgreements" ADD COLUMN IF NOT EXISTS "TermsText" text;
ALTER TABLE "RentAgreements" ADD COLUMN IF NOT EXISTS "GeneratedAt" timestamp with time zone;
ALTER TABLE "RentAgreements" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;
UPDATE "RentAgreements" SET "AgreementNumber" = 'AGR-' || "Id" WHERE "AgreementNumber" IS NULL OR "AgreementNumber"='';
UPDATE "RentAgreements" SET "TermsText" = 'Standard rental agreement terms.' WHERE "TermsText" IS NULL;
UPDATE "RentAgreements" SET "StartDate" = CURRENT_TIMESTAMP WHERE "StartDate" IS NULL;
UPDATE "RentAgreements" SET "EndDate" = CURRENT_TIMESTAMP + INTERVAL '1 year' WHERE "EndDate" IS NULL;
ALTER TABLE "RentAgreements" ALTER COLUMN "AgreementNumber" SET DEFAULT 'AGR-NEW';
ALTER TABLE "RentAgreements" ALTER COLUMN "AgreementNumber" SET NOT NULL;
ALTER TABLE "RentAgreements" ALTER COLUMN "TermsText" SET DEFAULT 'Standard rental agreement terms.';
ALTER TABLE "RentAgreements" ALTER COLUMN "TermsText" SET NOT NULL;
ALTER TABLE "RentAgreements" ALTER COLUMN "StartDate" SET NOT NULL;
ALTER TABLE "RentAgreements" ALTER COLUMN "EndDate" SET NOT NULL;
""";

        await using var command = new NpgsqlCommand(sql, connection);
        command.CommandTimeout = 60;
        await command.ExecuteNonQueryAsync();
    }
}
