using Citizen_Management.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Citizen_Management.Data;

public static class DbInitializer
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<ApplicationDbContext>();
        var hasher = services.GetRequiredService<IPasswordHasher<User>>();

        // Add AvatarUrl column directly to PostgreSQL if it does not already exist
        await db.Database.ExecuteSqlRawAsync("ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"AvatarUrl\" text;");

        // Seed or update Admin
        var admin = await db.Users.FirstOrDefaultAsync(x => x.Email == "admin@citizen.local");
        if (admin == null)
        {
            admin = new User
            {
                Name = "Administrator",
                FullName = "System Administrator",
                Email = "admin@citizen.local",
                Role = "admin",
                VerificationStatus = "verified"
            };
            admin.PasswordHash = hasher.HashPassword(admin, "Admin@123");
            db.Users.Add(admin);
        }

        // Seed or update Citizen
        var citizen = await db.Users.FirstOrDefaultAsync(x => x.Email == "citizen@citizen.local");
        if (citizen == null)
        {
            citizen = new User
            {
                Name = "Mohammad Rayan",
                FullName = "Mohammad Rayan",
                Email = "citizen@citizen.local",
                Role = "citizen",
                VerificationStatus = "verified",
                NidNumber = "9876543210",
                NationalId = "9876543210",
                FatherName = "Kabir Ahmed",
                MotherName = "Farida Begum",
                DateOfBirth = new DateTime(2001, 5, 14, 0, 0, 0, DateTimeKind.Utc),
                PresentAddress = "Chattogram, Bangladesh",
                PermanentAddress = "Chattogram, Bangladesh",
                PassportPhoto = null
            };
            citizen.PasswordHash = hasher.HashPassword(citizen, "Citizen@123");
            db.Users.Add(citizen);
        }
        else
        {
            // Sync database if citizen record already exists
            citizen.Name = "Mohammad Rayan";
            citizen.FullName = "Mohammad Rayan";
            citizen.NidNumber = "9876543210";
            citizen.NationalId = "9876543210";
            citizen.FatherName = "Kabir Ahmed";
            citizen.MotherName = "Farida Begum";
            citizen.DateOfBirth = new DateTime(2001, 5, 14, 0, 0, 0, DateTimeKind.Utc);
            citizen.PresentAddress = "Chattogram, Bangladesh";
            citizen.PermanentAddress = "Chattogram, Bangladesh";
            citizen.VerificationStatus = "verified";
        }

        await db.SaveChangesAsync();

        // Seed Property
        var property = await db.Properties.FirstOrDefaultAsync(x => x.OwnerId == citizen.Id);
        if (property == null)
        {
            property = new Property
            {
                OwnerId = citizen.Id,
                Title = "Demo Residential Property",
                Type = "residential",
                AddressLine = "Agrabad Commercial Area",
                City = "Chattogram",
                State = "Chattogram",
                PostalCode = "4100",
                AreaSqft = 1200,
                IsActive = true,
                IsAvailableForRent = true,
                RentPrice = 15000,
                AssessedValue = 2500000,
                LandUse = "residential",
                Description = "Demo property for testing the Citizen Management System."
            };
            db.Properties.Add(property);
            await db.SaveChangesAsync();
        }

        // Seed Tax Assessment
        var tax = await db.TaxAssessments.FirstOrDefaultAsync(x => x.PropertyId == property.Id && x.FiscalYear == "2026-2027");
        if (tax == null)
        {
            tax = new TaxAssessment
            {
                PropertyId = property.Id,
                OwnerId = citizen.Id,
                FiscalYear = "2026-2027",
                AssessedValueSnapshot = property.AssessedValue ?? 2500000m,
                LandUseSnapshot = property.LandUse,
                TaxRate = 0.01m,
                TaxAmount = Math.Round((property.AssessedValue ?? 2500000m) * 0.01m, 2),
                Status = "issued",
                IssuedAt = DateTime.UtcNow,
                DueDate = new DateTime(2027, 6, 30, 0, 0, 0, DateTimeKind.Utc),
                Notes = "Demo municipal tax assessment."
            };
            db.TaxAssessments.Add(tax);
        }

        // Seed Fake NIDs
        await EnsureFakeNid(db, "9876543210", "Mohammad Rayan", "Kabir Ahmed", "Farida Begum", new DateTime(2001, 5, 14, 0, 0, 0, DateTimeKind.Utc), "Male", true);
        await EnsureFakeNid(db, "1234567890", "Demo Citizen", "Demo Father", "Demo Mother", new DateTime(1998, 1, 10, 0, 0, 0, DateTimeKind.Utc), "Male", true);
        await EnsureFakeNid(db, "5544332211", "Sarah Rahman", "Mizanur Rahman", "Salma Begum", new DateTime(1999, 8, 22, 0, 0, 0, DateTimeKind.Utc), "Female", false);

        await db.SaveChangesAsync();
    }

    private static async Task EnsureFakeNid(ApplicationDbContext db, string nid, string name, string father, string mother, DateTime dob, string gender, bool verified)
    {
        var existing = await db.FakeNids.FirstOrDefaultAsync(x => x.Nid == nid);
        if (existing == null)
        {
            db.FakeNids.Add(new FakeNid
            {
                Nid = nid,
                Name = name,
                FatherName = father,
                MotherName = mother,
                DateOfBirth = dob,
                Gender = gender,
                PermanentAddress = "Chattogram, Bangladesh",
                PresentAddress = "Chattogram, Bangladesh",
                IsBlocked = false,
                IsVerified = verified
            });
        }
        else
        {
            existing.IsVerified = verified;
            existing.Name = name;
        }
    }
}