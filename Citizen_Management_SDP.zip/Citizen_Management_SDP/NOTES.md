## What was converted

The uploaded Laravel source was inspected directly and the application was rebuilt as a native ASP.NET Core MVC application.

The conversion is intentionally not a text-level PHP-to-C# rename. PHP framework concepts were replaced with .NET equivalents:

- Eloquent relationships → EF Core relationships
- Laravel auth → cookie authentication + password hashing + roles
- Blade → Razor
- Laravel routes → attribute-routed MVC actions
- Validation → ASP.NET Core model binding/validation
- Storage uploads → `wwwroot/uploads`
- Tax services → C# services
- Revenue dashboard/export → C# service/controller
- Fake NID API → ASP.NET Core API controller
- Artisan overdue command → `OverdueAssessmentService`
- Seeders → `DbInitializer`
- `.env` → `appsettings.json`
- Stripe → Stripe.NET optional integration

SQLite is used on first run so the converted project can start without requiring SQL Server. SQL Server can be enabled by changing the provider and connection string.
