-- MyCitizen legacy PostgreSQL repair script.
-- Run this once if an older database was created from a previous SQL schema.
-- It is non-destructive: it adds/renames missing columns and preserves rows.
/*ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "DueDate" timestamp with time zone;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "IssuedAt" timestamp with time zone;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "PaidAt" timestamp with time zone;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "LandUseSnapshot" text;
ALTER TABLE "TaxAssessments" ADD COLUMN IF NOT EXISTS "Notes" text;
DO $$ BEGIN
 IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxAssessments' AND column_name='FiscalYear' AND data_type <> 'text') THEN
   ALTER TABLE "TaxAssessments" ALTER COLUMN "FiscalYear" TYPE text USING "FiscalYear"::text;
 END IF;
END $$;
DO $$ BEGIN
 IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='PaymentDate') AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='PaidAt') THEN ALTER TABLE "TaxPayments" RENAME COLUMN "PaymentDate" TO "PaidAt"; END IF;
 IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='PaymentMethod') AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='Method') THEN ALTER TABLE "TaxPayments" RENAME COLUMN "PaymentMethod" TO "Method"; END IF;
 IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='TransactionId') AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='TaxPayments' AND column_name='Reference') THEN ALTER TABLE "TaxPayments" RENAME COLUMN "TransactionId" TO "Reference"; END IF;
END $$;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "PayerId" bigint;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "RecordedBy" bigint;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "Method" text;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "Reference" text;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "PaidAt" timestamp with time zone;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "Notes" text;
ALTER TABLE "TaxPayments" ADD COLUMN IF NOT EXISTS "CreatedAt" timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;
*/