# PostgreSQL setup

1. Create a PostgreSQL database named `Citizen_Management` in pgAdmin.
2. Open `appsettings.json` and replace `YOUR_POSTGRES_PASSWORD`.
3. The project uses `Npgsql.EntityFrameworkCore.PostgreSQL` and `UseNpgsql`.
4. On first application start, `EnsureCreatedAsync()` creates the schema and `DbInitializer` inserts demo users/property/NID records.
5. The complete manual PostgreSQL schema and useful queries are in `postgresql_all_queries.sql`.

Demo login created by the application:
- Admin: `admin@citizen.local` / `Admin@123`
- Citizen: `citizen@citizen.local` / `Citizen@123`

Do not commit a real PostgreSQL password to source control.
