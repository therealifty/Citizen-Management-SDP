using Citizen_Management.Data;
using Citizen_Management.Models;
using Citizen_Management.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

// Set Npgsql legacy timestamp behavior before any DB calls
AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

var builder = WebApplication.CreateBuilder(args);

// =====================================================
// MVC
// =====================================================
builder.Services.AddControllersWithViews();

// =====================================================
// PostgreSQL
// =====================================================
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(
        builder.Configuration.GetConnectionString("DefaultConnection")
    ));

// =====================================================
// Authentication
// =====================================================
builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.AccessDeniedPath = "/access-denied";

        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });

// =====================================================
// Authorization
// =====================================================
builder.Services.AddAuthorization();

// =====================================================
// Services
// =====================================================
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();
builder.Services.AddScoped<TaxAssessmentService>();
builder.Services.AddScoped<RevenueDashboardService>();
builder.Services.AddScoped<StripeCheckoutService>();
builder.Services.AddScoped<NidVerificationService>();

// =====================================================
// Build application
// =====================================================
var app = builder.Build();

// =====================================================
// PostgreSQL database initialization
// =====================================================
using (var scope = app.Services.CreateScope())
{
    try
    {
        var db = scope.ServiceProvider
            .GetRequiredService<ApplicationDbContext>();

        await PostgresSchemaManager.RepairAsync(db);

        await DbInitializer.SeedAsync(
            scope.ServiceProvider
        );
    }
    catch (Exception ex)
    {
        var logger = scope.ServiceProvider
            .GetRequiredService<ILogger<Program>>();

        logger.LogError(
            ex,
            "PostgreSQL database initialization failed."
        );
    }
}

// =====================================================
// Error handling
// =====================================================
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// =====================================================
// Middleware
// =====================================================
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

// =====================================================
// ROOT URL
// https://localhost:7250/
//        ↓
// https://localhost:7250/login
// =====================================================
app.MapGet("/", context =>
{
    context.Response.Redirect("/login");
    return Task.CompletedTask;
});

// =====================================================
// Controllers with attribute routes
// =====================================================
app.MapControllers();

// =====================================================
// MVC conventional routes
// =====================================================
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");

// =====================================================
// Start
// =====================================================
app.Run();