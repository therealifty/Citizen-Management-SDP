namespace Citizen_Management.Models;

public class User
{
    public long Id { get; set; }
    public string Name { get; set; } = "User Name";
    public string Email { get; set; } = "";
    public string? Phone { get; set; }
    public string? NationalId { get; set; }
    public string Role { get; set; } = "citizen";
    public string VerificationStatus { get; set; } = "pending";
    public string PasswordHash { get; set; } = "";
    public string? NidNumber { get; set; }
    public string? FullName { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? FatherName { get; set; }
    public string? MotherName { get; set; }
    public string? PermanentAddress { get; set; }
    public string? PresentAddress { get; set; }
    public string? PhoneNumber { get; set; }
    public string? NidFrontImage { get; set; }
    public string? NidBackImage { get; set; }
    public string? PassportPhoto { get; set; }
    public DateTime? VerificationRequestedAt { get; set; }
    public DateTime? VerifiedAt { get; set; }
    public long? VerifiedBy { get; set; }
    public DateTime? RejectedAt { get; set; }
    public long? RejectedBy { get; set; }
    public string? RejectionReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsAdmin() => Role == "admin";
    public bool IsCitizen() => Role == "citizen";
    public bool IsVerified() => VerificationStatus == "verified";
    public string DisplayName => !string.IsNullOrWhiteSpace(FullName) ? FullName : Name;
}