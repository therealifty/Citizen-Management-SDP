namespace Citizen_Management.Models;
public class TaxPayment {
    public long Id { get; set; }
    public long TaxAssessmentId { get; set; }
    public TaxAssessment? Assessment { get; set; }
    public long? PayerId { get; set; }
    public User? Payer { get; set; }
    public long? RecordedBy { get; set; }
    public decimal Amount { get; set; }
    public string? Method { get; set; }
    public string? Reference { get; set; }
    public DateTime? PaidAt { get; set; }
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}