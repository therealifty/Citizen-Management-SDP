namespace Citizen_Management.Models;
public class FakeNid {
    public long Id { get; set; }
    public string Nid { get; set; } = "";
    public string Name { get; set; } = "";
    public string FatherName { get; set; } = "";
    public string MotherName { get; set; } = "";
    public DateTime DateOfBirth { get; set; }
    public string Gender { get; set; } = "Other";
    public string? BirthPlace { get; set; }
    public string? PresentAddress { get; set; }
    public string? PermanentAddress { get; set; }
    public string? BloodGroup { get; set; }
    public string? Reason { get; set; }
    public bool IsBlocked { get; set; } = true;
    public bool IsVerified { get; set; }
    public DateTime? VerifiedAt { get; set; }
    public long? VerifiedBy { get; set; }
}