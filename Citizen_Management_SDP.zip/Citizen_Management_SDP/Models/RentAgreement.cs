namespace Citizen_Management.Models;
public class RentAgreement {
    public long Id { get; set; }
    public long PropertyId { get; set; }
    public Property? Property { get; set; }
    public long? RentalRequestId { get; set; }
    public RentalRequest? RentalRequest { get; set; }
    public long LandlordId { get; set; }
    public User? Landlord { get; set; }
    public long TenantId { get; set; }
    public User? Tenant { get; set; }
    public long? ApprovedBy { get; set; }
    public string AgreementNumber { get; set; } = "";
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public decimal MonthlyRent { get; set; }
    public decimal SecurityDeposit { get; set; }
    public string TermsText { get; set; } = "";
    public string Status { get; set; } = "active";
    public DateTime? GeneratedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}