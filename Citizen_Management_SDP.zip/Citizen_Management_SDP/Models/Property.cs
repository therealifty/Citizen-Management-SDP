namespace Citizen_Management.Models;
public class Property {
    public long Id { get; set; }
    public long? OwnerId { get; set; }
    public User? Owner { get; set; }
    public string Title { get; set; } = "";
    public string Type { get; set; } = "residential";
    public string? AddressLine { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? PostalCode { get; set; }
    public decimal? AreaSqft { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsAvailableForRent { get; set; }
    public decimal? RentPrice { get; set; }
    public decimal? AssessedValue { get; set; }
    public string? LandUse { get; set; }
    public DateTime? LastValuationAt { get; set; }
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public ICollection<TaxAssessment> TaxAssessments { get; set; } = new List<TaxAssessment>();
    public ICollection<RentalRequest> RentalRequests { get; set; } = new List<RentalRequest>();
    public ICollection<RentAgreement> RentAgreements { get; set; } = new List<RentAgreement>();
}