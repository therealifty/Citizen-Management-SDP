namespace Citizen_Management.Models;
public class PropertyRequest {
    public long Id { get; set; }
    public long UserId { get; set; }
    public User? User { get; set; }
    public long? PropertyId { get; set; }
    public Property? Property { get; set; }
    public string Type { get; set; } = "";
    public string Payload { get; set; } = "{}";
    public string Status { get; set; } = "pending";
    public string? DecisionNote { get; set; }
    public long? DecidedBy { get; set; }
    public DateTime? DecidedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}