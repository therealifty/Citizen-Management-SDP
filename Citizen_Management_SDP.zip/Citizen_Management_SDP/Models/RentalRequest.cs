namespace Citizen_Management.Models;
public class RentalRequest {
    public long Id { get; set; }
    public long PropertyId { get; set; }
    public Property? Property { get; set; }
    public long UserId { get; set; }
    public User? User { get; set; }
    public string Status { get; set; } = "pending";
    public string? Message { get; set; }
    public DateTime? TenantStartDate { get; set; }
    public DateTime? TenantEndDate { get; set; }
    public decimal? TenantMonthlyRent { get; set; }
    public decimal? TenantSecurityDeposit { get; set; }
    public DateTime? OwnerStartDate { get; set; }
    public DateTime? OwnerEndDate { get; set; }
    public decimal? OwnerMonthlyRent { get; set; }
    public decimal? OwnerSecurityDeposit { get; set; }
    public string? OwnerNotes { get; set; }
    public bool ReadyForAdmin { get; set; }
    public DateTime? OwnerConfirmedAt { get; set; }
    public long? OwnerConfirmedBy { get; set; }
    public string? DecisionNote { get; set; }
    public long? DecidedBy { get; set; }
    public DateTime? DecidedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public RentAgreement? RentAgreement { get; set; }
}