namespace Citizen_Management.Models;
public class TaxAssessment {
    public long Id { get; set; }
    public long PropertyId { get; set; }
    public Property? Property { get; set; }
    public long OwnerId { get; set; }
    public User? Owner { get; set; }
    public string FiscalYear { get; set; } = "";
    public decimal AssessedValueSnapshot { get; set; }
    public string? LandUseSnapshot { get; set; }
    public decimal TaxRate { get; set; }
    public decimal TaxAmount { get; set; }
    public string Status { get; set; } = "draft";
    public DateTime? DueDate { get; set; }
    public DateTime? IssuedAt { get; set; }
    public DateTime? PaidAt { get; set; }
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public ICollection<TaxPayment> Payments { get; set; } = new List<TaxPayment>();
    public void MarkPaidIfSettled() {
        if (Payments.Sum(x => x.Amount) >= TaxAmount) { Status = "paid"; PaidAt = DateTime.UtcNow; }
    }
}