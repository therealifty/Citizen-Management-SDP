namespace Citizen_Management.Models;
public class Complaint {
    public long Id { get; set; }
    public long UserId { get; set; }
    public User? User { get; set; }
    public long? PropertyId { get; set; }
    public Property? Property { get; set; }
    public string? Category { get; set; }
    public string Subject { get; set; } = "";
    public string Description { get; set; } = "";
    public string Status { get; set; } = "open";
    public string? AdminReply { get; set; }
    public string? AttachmentPath { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public long? ResolvedBy { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}